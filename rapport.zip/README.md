# Rapport de stage PFA — Chouaib MOUKAOUIL

Rapport LaTeX du Projet de Fin d'Année réalisé chez CIH Bank (EMSI Casablanca,
2025–2026), portant sur les deux projets **Audit-Tool** et **GovernX**.

## Compilation

```bash
pdflatex main.tex     # 3 passes pour résoudre TOC, figures et références
pdflatex main.tex
pdflatex main.tex
```

ou, plus simplement :

```bash
latexmk -pdf main.tex
```

Aucune dépendance externe hors distribution LaTeX standard (MiKTeX ou TeX Live).
Les paquets utilisés — `babel`, `geometry`, `fancyhdr`, `booktabs`, `tabularx`,
`listings`, `tikz`, `hyperref`, `microtype` — sont tous inclus dans une
installation complète.

> **Note MiKTeX** : cette installation présente une incompatibilité de version
> entre `array` et `colortbl`/`longtable`. Ces deux paquets ne sont donc pas
> utilisés ; toutes les tables reposent sur `tabularx`.

## Structure

```
rapport/
├── main.tex                    # préambule, mise en page, ordre des sections
├── images/
│   ├── logo-emsi.jpg
│   └── logo-cih.png
└── sections/
    ├── 00-pagedegarde.tex      # page de garde (les 2 logos)
    ├── 01-dedicace.tex
    ├── 02-remerciements.tex
    ├── 03-resume.tex           # résumé FR + abstract EN
    ├── 04-abreviations.tex
    ├── 05-introduction.tex     # introduction générale
    ├── 06-chapitre1.tex        # contexte général (CIH, EMSI, problématique)
    ├── 07-chapitre2.tex        # étude technique et choix technologiques
    ├── 08-chapitre3.tex        # Audit-Tool
    ├── 09-chapitre4.tex        # GovernX
    ├── 10-chapitre5.tex        # bilan, difficultés, perspectives
    ├── 11-conclusion.tex
    ├── 12-annexes.tex
    └── 13-bibliographie.tex
```

## Pagination

| Partie | Pages |
| --- | --- |
| Pages liminaires (garde, dédicace, remerciements, résumé, TdM, listes, abréviations) | 9 (numérotation romaine) |
| **Corps du rapport** (introduction générale → conclusion générale) | **37** |
| Annexes + webographie | 6 |
| **Total PDF** | **52** |

Le corps du rapport respecte la limite de 30 à 40 pages. Pour réduire le total
imprimé, les leviers les plus simples, par ordre de rendement :

1. supprimer le chapitre des annexes (`12-annexes.tex`) — les informations y sont
   complémentaires, non essentielles : **−4 pages** ;
2. supprimer la dédicace (`01-dedicace.tex`) : **−1 page** ;
3. dans `main.tex`, passer `\setstretch{1.04}` à `1.0` : **−2 à 3 pages**.

## Éléments à personnaliser avant remise

- **Encadrant pédagogique EMSI** : le nom est laissé en pointillés sur la page de
  garde (`sections/00-pagedegarde.tex`).
- **Dédicace** : à réécrire selon les souhaits personnels
  (`sections/01-dedicace.tex`).
- **Dates de stage** : la période « juillet – août 2026 » figure sur la page de
  garde et dans le tableau 1.1 ; à ajuster si nécessaire.
- **Captures d'écran** : le rapport n'en contient aucune. Ajouter, si les règles
  de confidentialité de CIH Bank le permettent, une capture du rapport d'audit
  HTML et une du pipeline GitLab vert renforcerait le chapitre 3 et le
  chapitre 4.
